package cobaKonsepOOP;

public class Obstacle {
	
	private int damage;

}
