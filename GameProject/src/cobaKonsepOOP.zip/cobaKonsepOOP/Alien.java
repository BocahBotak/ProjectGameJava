package cobaKonsepOOP;

public class Alien extends Enemy {

	public Alien(int hp, int damage, int x, int y) {
		super(hp, damage, x, y);
		// TODO Auto-generated constructor stub
	}



}
