package cobaKonsepOOP;

public class Supplier {

	private int time;
	
}
