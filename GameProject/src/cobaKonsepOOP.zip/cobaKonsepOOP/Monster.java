package cobaKonsepOOP;

public class Monster extends Enemy {

	public Monster(int hp, int damage, int x, int y) {
		super(hp, damage, x, y);
		// TODO Auto-generated constructor stub
	}



}
