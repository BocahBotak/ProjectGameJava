package cobaKonsepOOP;

public class Bullet {

}
