package cobaKonsepOOP;

import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class GamePanel extends JPanel {

	private ImageIcon bg = new ImageIcon("background.jpg");
	private ImageIcon img = new ImageIcon("pesawat.png");
	private Plane player = new Plane(1000, 100, 200 - (getW() / 2), 600);
	private int w = getImg().getIconWidth()/3;
	private int h = getImg().getIconHeight()/8;
	private int xgambar = 0;

	public int getXgambar() {
		return xgambar;
	}
	
	KeyListener control = new KeyListener() {
		
		@Override
		public void keyTyped(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void keyReleased(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void keyPressed(KeyEvent e) {
			System.out.println(player.x + " " + player.y);
			switch (e.getKeyCode()) {
			case KeyEvent.VK_W:
				if (player.y - 20 > 350) {
					player.y -= 20;
				}
				break;
			case KeyEvent.VK_A:
				if (player.x - 20 >= 0) {
					player.x -= 20;
				}
				break;
			case KeyEvent.VK_S:
				if (player.y + h + 20 <= 700) {
					player.y += 20;
				}
				break;
			case KeyEvent.VK_D:
				if (player.x + w + 20 <= 400) {
					player.x += 20;
				}
				break;
			case KeyEvent.VK_1:
//				skill = 1;
				break;
			case KeyEvent.VK_2:
//				skill = 2;
				break;
			case KeyEvent.VK_3:
//				skill = 3;
				break;
			case KeyEvent.VK_SPACE:
//				if (skill == 1) {
//					peluru1.add(new Rectangle((int) player.getCenterX(), player.y - 5, 2, 5));
//				} else if (skill == 2) {
//					peluru1.add(new Rectangle((int) player.getCenterX(), player.y - 5, 2, 5));
//					peluru2.add(new Rectangle((int) player.getCenterX(), player.y - 5, 2, 5));
//					peluru3.add(new Rectangle((int) player.getCenterX(), player.y - 5, 2, 5));
//				} else if (skill == 3) {
//					peluru1.add(new Rectangle((int) player.getCenterX(), player.y - 5, 2, 5));
//				}
				break;
			default:
				break;
			}
			repaint();
		}
	};

	public GamePanel() {
		addKeyListener(control);
		move.start();
	}
	
	Thread move = new Thread(()->{
		while(true) {
			xgambar++;
			xgambar %= 3;
			repaint();
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	});

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		g.clearRect(0, 0, 1000, 1000);
//		System.out.println(player.x + " " + player.y);
		g.drawImage(bg.getImage(), 0, 0, 400, 700, 750, 210, 1200, 1000, null);
		g.drawImage(img.getImage(), player.getX(), player.getY(),
				player.getX() + w, player.getY() + h,
				xgambar * w, 0, xgambar * w + w, h, null);
	}

	public ImageIcon getBg() {
		return bg;
	}

	public ImageIcon getImg() {
		return img;
	}

	public Plane getPlayer() {
		return player;
	}

	public int getW() {
		return w;
	}

	public int getH() {
		return h;
	}
}