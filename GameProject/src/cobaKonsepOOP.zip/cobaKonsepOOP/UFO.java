package cobaKonsepOOP;

public class UFO extends Enemy {

	public UFO(int hp, int damage, int x, int y) {
		super(hp, damage, x, y);
		// TODO Auto-generated constructor stub
	}

	

}
